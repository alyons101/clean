import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Star, Check, Phone, MessageCircle, Calendar, MapPin, 
  Shield, Zap, TrendingUp, ChevronRight,
  Menu, X, ArrowRight, Sparkles, Home, User, CreditCard,
  BadgeCheck, AlertCircle, Lock
} from 'lucide-react'
import { format, addDays, startOfToday } from 'date-fns'
import './App.css'

// Types
interface BookingData {
  service: string
  date: Date | null
  timeSlot: string
  postcode: string
  duration: number
  email: string
  phone: string
}

interface CleanerProfile {
  name: string
  phone: string
  postcode: string
  experience: string
  availability: Record<string, string[]>
}

// Navigation Component
function Navigation({ onBookClick, onCleanerClick }: { onBookClick: () => void, onCleanerClick: () => void }) {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 100)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/90 backdrop-blur-md shadow-elevation' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <motion.div 
            className="flex items-center gap-2"
            whileHover={{ scale: 1.02 }}
          >
            <div className="w-8 h-8 bg-electric rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold text-xl text-nearblack">SparkClean</span>
          </motion.div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            <button onClick={onBookClick} className="sc-btn-ghost">Book</button>
            <button onClick={onCleanerClick} className="sc-btn-ghost">Join as a cleaner</button>
            <button className="sc-btn-ghost">Support</button>
          </nav>

          {/* Binary CTAs */}
          <div className="hidden md:flex items-center gap-3">
            <button onClick={onCleanerClick} className="sc-btn-secondary text-sm py-2.5">
              Become Cleaner
            </button>
            <button onClick={onBookClick} className="sc-btn-primary text-sm py-2.5">
              Book Clean
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-navy-100"
          >
            <div className="px-4 py-4 space-y-2">
              <button onClick={() => { onBookClick(); setIsMobileMenuOpen(false) }} className="w-full sc-btn-primary">
                Book Clean
              </button>
              <button onClick={() => { onCleanerClick(); setIsMobileMenuOpen(false) }} className="w-full sc-btn-secondary">
                Become Cleaner
              </button>
              <button className="w-full sc-btn-ghost justify-center">Support</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  )
}

// Hero Section
function HeroSection({ onBookClick }: { onBookClick: () => void }) {
  const [formData, setFormData] = useState({ postcode: '', date: '', email: '' })
  const [availableCleaners] = useState(3)

  return (
    <section className="sc-section min-h-screen relative flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=1920&q=80" 
          alt="Modern living room"
          className="sc-bg-image"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-offwhite/95 via-offwhite/80 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Left: Headline */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }}
          >
            {/* Live Counter */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="sc-live-counter mb-6"
            >
              <span className="sc-live-dot" />
              <span>{availableCleaners} cleaners available in SW6 today</span>
            </motion.div>

            {/* Headline */}
            <h1 className="sc-headline-hero text-nearblack mb-6">
              <span className="block">SPOTLESS</span>
              <span className="block">HOMES.</span>
              <span className="block text-electric">ZERO STRESS.</span>
            </h1>

            {/* Subheadline */}
            <p className="sc-body text-lg mb-6 max-w-md">
              Book a vetted cleaner in under 60 seconds. Trusted by 10,000+ homes across London.
            </p>

            {/* Trust Badges */}
            <div className="flex flex-wrap items-center gap-4 mb-8">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-electric fill-electric" />
                ))}
                <span className="ml-2 font-semibold text-nearblack">4.9/5</span>
                <span className="text-navy-500">(2,847 reviews)</span>
              </div>
              <div className="flex items-center gap-2 text-navy-600">
                <BadgeCheck className="w-5 h-5 text-emerald" />
                <span className="text-sm">Trustpilot</span>
              </div>
            </div>

            {/* CTA */}
            <motion.button
              onClick={onBookClick}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="sc-btn-primary text-lg px-8 py-4"
            >
              Book a clean
              <ArrowRight className="w-5 h-5 ml-2 inline" />
            </motion.button>

            <p className="mt-4 text-sm text-navy-500">
              No hidden fees. Change or cancel anytime.
            </p>
          </motion.div>

          {/* Right: Booking Card */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.25, 0.1, 0.25, 1] }}
            className="sc-card p-6 md:p-8"
          >
            <h2 className="font-display font-bold text-2xl mb-6">Book your clean</h2>
            
            <div className="space-y-4">
              <div>
                <label className="sc-label mb-2 block">Postcode</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                  <input
                    type="text"
                    placeholder="e.g. SW6 1AA"
                    value={formData.postcode}
                    onChange={(e) => setFormData({ ...formData, postcode: e.target.value })}
                    className="sc-input w-full pl-12"
                  />
                </div>
              </div>

              <div>
                <label className="sc-label mb-2 block">Date</label>
                <div className="relative">
                  <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="sc-input w-full pl-12"
                    min={format(addDays(startOfToday(), 1), 'yyyy-MM-dd')}
                  />
                </div>
              </div>

              <div>
                <label className="sc-label mb-2 block">Email</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                  <input
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="sc-input w-full pl-12"
                  />
                </div>
              </div>

              <motion.button
                onClick={onBookClick}
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                className="sc-btn-primary w-full mt-6"
              >
                Get a price
              </motion.button>

              <p className="text-center text-sm text-navy-500 mt-4">
                Join 10,000+ happy homes
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// Value Prop Section
function ValuePropSection() {
  return (
    <section className="sc-section min-h-screen relative flex items-center justify-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=1920&q=80" 
          alt="Cozy living room"
          className="sc-bg-image"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-nearblack/60 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4">
        <motion.p
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-white/90 text-lg md:text-xl mb-4"
        >
          From sinks to sofas, we do the heavy lifting.
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="sc-headline text-white"
        >
          WE'LL HANDLE IT.
        </motion.h2>
      </div>
    </section>
  )
}

// Trust Section
function TrustSection() {
  return (
    <section className="sc-section min-h-screen relative flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1920&q=80" 
          alt="Modern living room with windows"
          className="sc-bg-image"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-offwhite/95 via-offwhite/70 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Left: Headline */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="sc-headline text-nearblack">
              <span className="block">SPARKCLEAN</span>
              <span className="block text-electric">IS TRUSTED.</span>
            </h2>
          </motion.div>

          {/* Right: Review Card */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="sc-card p-6 md:p-8"
          >
            {/* Stars */}
            <div className="flex gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.6 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3 + i * 0.05 }}
                >
                  <Star className="w-6 h-6 text-electric fill-electric" />
                </motion.div>
              ))}
            </div>

            {/* Quote */}
            <blockquote className="text-lg md:text-xl text-nearblack mb-6 leading-relaxed">
              "They cleaned places I didn't know I had. Super polite, on time, and the flat smelled amazing."
            </blockquote>

            {/* Reviewer */}
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-electric-100 flex items-center justify-center">
                <span className="font-display font-bold text-electric">A</span>
              </div>
              <div>
                <p className="font-semibold text-nearblack">Amina</p>
                <p className="text-sm text-navy-500">London • Verified review</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// Feature Section Component
function FeatureSection({ 
  headline, 
  highlight,
  cardTitle, 
  bullets, 
  linkText,
  imageUrl,
  reversed = false 
}: { 
  headline: string
  highlight: string
  cardTitle: string
  bullets: string[]
  linkText: string
  imageUrl: string
  reversed?: boolean
}) {
  return (
    <section className="sc-section min-h-screen relative flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src={imageUrl}
          alt="Feature background"
          className="sc-bg-image"
        />
        <div className={`absolute inset-0 bg-gradient-to-${reversed ? 'l' : 'r'} from-offwhite/95 via-offwhite/70 to-transparent`} />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`grid lg:grid-cols-2 gap-8 lg:gap-12 items-center ${reversed ? 'lg:flex-row-reverse' : ''}`}>
          {/* Left: Headline */}
          <motion.div
            initial={{ opacity: 0, x: reversed ? 40 : -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="sc-headline text-nearblack">
              <span className="block">{headline}</span>
              <span className="block text-electric">{highlight}</span>
            </h2>
          </motion.div>

          {/* Right: Feature Card */}
          <motion.div
            initial={{ opacity: 0, x: reversed ? -40 : 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="sc-card p-6 md:p-8"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-electric-100 rounded-xl flex items-center justify-center">
                <Zap className="w-5 h-5 text-electric" />
              </div>
              <h3 className="font-display font-bold text-xl">{cardTitle}</h3>
            </div>

            <ul className="space-y-3 mb-6">
              {bullets.map((bullet, i) => (
                <motion.li
                  key={i}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  className="flex items-start gap-3"
                >
                  <Check className="w-5 h-5 text-emerald flex-shrink-0 mt-0.5" />
                  <span className="text-navy-700">{bullet}</span>
                </motion.li>
              ))}
            </ul>

            <button className="text-electric font-semibold flex items-center gap-2 hover:gap-3 transition-all">
              {linkText}
              <ChevronRight className="w-5 h-5" />
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// Booking Flow Component
function BookingFlow({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState(1)
  const [bookingData, setBookingData] = useState<BookingData>({
    service: 'regular',
    date: null,
    timeSlot: '',
    postcode: '',
    duration: 2,
    email: '',
    phone: ''
  })

  const services = [
    { id: 'eot', name: 'End of Tenancy', price: 20, description: 'Move-in ready guarantee' },
    { id: 'regular', name: 'Regular Cleaning', price: 15, description: 'Weekly or fortnightly', popular: true },
    { id: 'deep', name: 'Deep Cleaning', price: 18, description: 'Thorough deep clean' },
  ]

  const timeSlots = [
    { id: 'morning', label: 'Morning', time: '8AM - 12PM', popular: true },
    { id: 'afternoon', label: 'Afternoon', time: '12PM - 4PM', popular: false },
    { id: 'evening', label: 'Evening', time: '4PM - 8PM', popular: false },
  ]

  const next14Days = Array.from({ length: 14 }, (_, i) => addDays(startOfToday(), i + 1))

  const totalPrice = (services.find(s => s.id === bookingData.service)?.price || 15) * bookingData.duration

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <div>
              <h3 className="font-display font-bold text-xl mb-2">Choose your service</h3>
              <p className="text-navy-500 text-sm">Select the type of cleaning you need</p>
            </div>

            <div className="space-y-3">
              {services.map((service) => (
                <motion.button
                  key={service.id}
                  onClick={() => setBookingData({ ...bookingData, service: service.id })}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                    bookingData.service === service.id 
                      ? 'border-electric bg-electric-50' 
                      : 'border-navy-200 hover:border-electric-300'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-nearblack">{service.name}</span>
                        {service.popular && (
                          <span className="px-2 py-0.5 bg-electric text-white text-xs font-semibold rounded-full">
                            Popular
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-navy-500 mt-1">{service.description}</p>
                    </div>
                    <div className="text-right">
                      <span className="font-display font-bold text-electric">£{service.price}</span>
                      <span className="text-navy-400 text-sm">/hr</span>
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>

            {/* Price Anchor Psychology */}
            <div className="p-4 bg-navy-50 rounded-xl">
              <div className="flex items-center gap-2 text-sm text-navy-600">
                <Sparkles className="w-4 h-4 text-electric" />
                <span>Regular cleaning saves you £5/hr compared to one-off deep cleans</span>
              </div>
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-6">
            <div>
              <h3 className="font-display font-bold text-xl mb-2">When do you need it?</h3>
              <p className="text-navy-500 text-sm">Choose your preferred date and time</p>
            </div>

            {/* Calendar */}
            <div>
              <label className="sc-label mb-3 block">Select date</label>
              <div className="grid grid-cols-7 gap-2">
                {next14Days.map((date, i) => {
                  const isSelected = bookingData.date && format(bookingData.date, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
                  const isPopular = i === 2 || i === 3 || i === 4
                  return (
                    <motion.button
                      key={i}
                      onClick={() => setBookingData({ ...bookingData, date })}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className={`aspect-square rounded-xl flex flex-col items-center justify-center text-sm transition-all ${
                        isSelected 
                          ? 'bg-electric text-white' 
                          : 'bg-white border border-navy-200 hover:border-electric'
                      }`}
                    >
                      <span className="text-xs uppercase">{format(date, 'EEE')}</span>
                      <span className="font-semibold">{format(date, 'd')}</span>
                      {isPopular && !isSelected && (
                        <span className="absolute -top-1 -right-1 w-2 h-2 bg-electric rounded-full" />
                      )}
                    </motion.button>
                  )
                })}
              </div>
            </div>

            {/* Time Slots */}
            <div>
              <label className="sc-label mb-3 block">Select time</label>
              <div className="grid grid-cols-3 gap-3">
                {timeSlots.map((slot) => (
                  <motion.button
                    key={slot.id}
                    onClick={() => setBookingData({ ...bookingData, timeSlot: slot.id })}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className={`p-3 rounded-xl border-2 text-center transition-all relative ${
                      bookingData.timeSlot === slot.id 
                        ? 'border-electric bg-electric text-white' 
                        : 'border-navy-200 hover:border-electric-300'
                    }`}
                  >
                    {slot.popular && (
                      <span className="absolute -top-2 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-electric text-white text-xs font-semibold rounded-full">
                        Most booked
                      </span>
                    )}
                    <span className="block font-semibold">{slot.label}</span>
                    <span className={`text-xs ${bookingData.timeSlot === slot.id ? 'text-white/80' : 'text-navy-500'}`}>
                      {slot.time}
                    </span>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Scarcity Indicator */}
            <div className="flex items-center gap-2 text-amber-600 text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>Only 2 slots left for tomorrow morning</span>
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-6">
            <div>
              <h3 className="font-display font-bold text-xl mb-2">Where and how long?</h3>
              <p className="text-navy-500 text-sm">Tell us about your space</p>
            </div>

            {/* Postcode */}
            <div>
              <label className="sc-label mb-2 block">Postcode</label>
              <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type="text"
                  placeholder="e.g. SW6 1AA"
                  value={bookingData.postcode}
                  onChange={(e) => setBookingData({ ...bookingData, postcode: e.target.value })}
                  className="sc-input w-full pl-12 uppercase"
                />
              </div>
            </div>

            {/* Duration Slider */}
            <div>
              <label className="sc-label mb-3 block">Duration</label>
              <div className="grid grid-cols-4 gap-2">
                {[2, 3, 4, 5].map((hours) => (
                  <motion.button
                    key={hours}
                    onClick={() => setBookingData({ ...bookingData, duration: hours })}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className={`p-3 rounded-xl border-2 text-center transition-all ${
                      bookingData.duration === hours 
                        ? 'border-electric bg-electric text-white' 
                        : 'border-navy-200 hover:border-electric-300'
                    }`}
                  >
                    <Home className="w-5 h-5 mx-auto mb-1" />
                    <span className="block font-semibold text-sm">{hours} hrs</span>
                    <span className={`text-xs ${bookingData.duration === hours ? 'text-white/80' : 'text-navy-500'}`}>
                      {hours === 2 ? 'Studio' : hours === 3 ? '1 bed' : hours === 4 ? '2 bed' : '3+ bed'}
                    </span>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Price Calculator */}
            <div className="p-4 bg-navy-50 rounded-xl">
              <div className="flex justify-between items-center mb-2">
                <span className="text-navy-600">Service</span>
                <span className="font-medium">{services.find(s => s.id === bookingData.service)?.name}</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-navy-600">Duration</span>
                <span className="font-medium">{bookingData.duration} hours</span>
              </div>
              <div className="border-t border-navy-200 pt-2 mt-2">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Total</span>
                  <span className="font-display font-bold text-2xl text-electric">£{totalPrice}</span>
                </div>
              </div>
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-6">
            <div>
              <h3 className="font-display font-bold text-xl mb-2">Almost done!</h3>
              <p className="text-navy-500 text-sm">Enter your details to confirm</p>
            </div>

            {/* Email */}
            <div>
              <label className="sc-label mb-2 block">Email</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type="email"
                  placeholder="your@email.com"
                  value={bookingData.email}
                  onChange={(e) => setBookingData({ ...bookingData, email: e.target.value })}
                  className="sc-input w-full pl-12"
                />
              </div>
            </div>

            {/* Phone (optional) */}
            <div>
              <label className="sc-label mb-2 block">Phone (optional)</label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type="tel"
                  placeholder="+44 7XXX XXXXXX"
                  value={bookingData.phone}
                  onChange={(e) => setBookingData({ ...bookingData, phone: e.target.value })}
                  className="sc-input w-full pl-12"
                />
              </div>
            </div>

            {/* Payment Options */}
            <div className="space-y-3">
              <p className="sc-label">Payment method</p>
              <div className="grid grid-cols-2 gap-3">
                <button className="p-4 rounded-xl border-2 border-electric bg-electric-50 flex flex-col items-center gap-2">
                  <CreditCard className="w-6 h-6 text-electric" />
                  <span className="font-medium text-sm">Pay after clean</span>
                </button>
                <button className="p-4 rounded-xl border-2 border-navy-200 hover:border-electric-300 flex flex-col items-center gap-2">
                  <Lock className="w-6 h-6 text-navy-400" />
                  <span className="font-medium text-sm text-navy-600">Pay now</span>
                </button>
              </div>
            </div>

            {/* Trust Signals */}
            <div className="flex items-center justify-center gap-4 text-sm text-navy-500">
              <div className="flex items-center gap-1">
                <Shield className="w-4 h-4 text-emerald" />
                <span>Secure checkout</span>
              </div>
              <div className="flex items-center gap-1">
                <Check className="w-4 h-4 text-emerald" />
                <span>Free cancellation</span>
              </div>
            </div>

            {/* Summary */}
            <div className="p-4 bg-navy-50 rounded-xl text-sm">
              <div className="flex justify-between mb-1">
                <span className="text-navy-600">{services.find(s => s.id === bookingData.service)?.name}</span>
                <span>{bookingData.duration} hrs</span>
              </div>
              <div className="flex justify-between mb-1">
                <span className="text-navy-600">
                  {bookingData.date ? format(bookingData.date, 'EEE, MMM d') : 'Date TBD'}
                </span>
                <span>{timeSlots.find(t => t.id === bookingData.timeSlot)?.label || 'Time TBD'}</span>
              </div>
              <div className="border-t border-navy-200 pt-2 mt-2 flex justify-between">
                <span className="font-semibold">Total</span>
                <span className="font-display font-bold text-electric">£{totalPrice}</span>
              </div>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-navy-900/50 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="sc-card w-full max-w-lg max-h-[90vh] overflow-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-navy-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-electric rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold">Book your clean</span>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-navy-100 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="px-6 pt-6">
          <div className="sc-step-indicator">
            {[1, 2, 3, 4].map((s) => (
              <div
                key={s}
                className={`sc-step-dot ${s === step ? 'active' : s < step ? 'completed' : ''}`}
              />
            ))}
          </div>
          <p className="text-sm text-navy-500 mt-2">Step {step} of 4</p>
        </div>

        {/* Content */}
        <div className="p-6">
          {renderStep()}
        </div>

        {/* Footer */}
        <div className="flex gap-3 p-6 border-t border-navy-100">
          {step > 1 && (
            <button
              onClick={() => setStep(step - 1)}
              className="sc-btn-secondary flex-1"
            >
              Back
            </button>
          )}
          <button
            onClick={() => step < 4 ? setStep(step + 1) : onClose()}
            className="sc-btn-primary flex-1"
          >
            {step === 4 ? 'Confirm booking' : 'Continue'}
          </button>
        </div>
      </motion.div>
    </motion.div>
  )
}

// Cleaner Application Flow
function CleanerApplicationFlow({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState(1)
  const [profile, setProfile] = useState<CleanerProfile>({
    name: '',
    phone: '',
    postcode: '',
    experience: '0-1',
    availability: {}
  })
  const [verificationComplete, setVerificationComplete] = useState(false)

  const experienceLevels = [
    { id: '0-1', label: '0-1 years', description: 'Just starting out' },
    { id: '1-3', label: '1-3 years', description: 'Some experience' },
    { id: '3+', label: '3+ years', description: 'Experienced pro' },
  ]

  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  const timeBlocks = ['Morning', 'Afternoon', 'Evening']

  const toggleAvailability = (day: string, time: string) => {
    const current = profile.availability[day] || []
    const updated = current.includes(time)
      ? current.filter(t => t !== time)
      : [...current, time]
    setProfile({ ...profile, availability: { ...profile.availability, [day]: updated } })
  }

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="font-display font-bold text-2xl mb-2">Earn £600+/week</h3>
              <p className="text-navy-500">Join 40+ cleaners in our private WhatsApp network</p>
            </div>

            <div>
              <label className="sc-label mb-2 block">Mobile number</label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type="tel"
                  placeholder="+44 7XXX XXXXXX"
                  value={profile.phone}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  className="sc-input w-full pl-12"
                />
              </div>
            </div>

            <div className="p-4 bg-emerald-50 rounded-xl">
              <div className="flex items-start gap-3">
                <TrendingUp className="w-5 h-5 text-emerald flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-emerald-800">Top cleaners earn £800+ weekly</p>
                  <p className="text-sm text-emerald-700 mt-1">Work flexible hours, get paid weekly, keep 100% of tips</p>
                </div>
              </div>
            </div>

            <div className="sc-whatsapp-btn w-full justify-center">
              <MessageCircle className="w-5 h-5" />
              <span>Continue on WhatsApp</span>
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-6">
            <div>
              <h3 className="font-display font-bold text-xl mb-2">Quick profile</h3>
              <p className="text-navy-500 text-sm">Tell us a bit about yourself</p>
            </div>

            <div>
              <label className="sc-label mb-2 block">Full name</label>
              <input
                type="text"
                placeholder="Your name"
                value={profile.name}
                onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                className="sc-input w-full"
              />
            </div>

            <div>
              <label className="sc-label mb-2 block">Postcode</label>
              <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type="text"
                  placeholder="e.g. SW6 1AA"
                  value={profile.postcode}
                  onChange={(e) => setProfile({ ...profile, postcode: e.target.value })}
                  className="sc-input w-full pl-12 uppercase"
                />
              </div>
            </div>

            <div>
              <label className="sc-label mb-3 block">Experience level</label>
              <div className="space-y-2">
                {experienceLevels.map((level) => (
                  <motion.button
                    key={level.id}
                    onClick={() => setProfile({ ...profile, experience: level.id })}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                      profile.experience === level.id 
                        ? 'border-electric bg-electric-50' 
                        : 'border-navy-200 hover:border-electric-300'
                    }`}
                  >
                    <span className="font-semibold text-nearblack">{level.label}</span>
                    <p className="text-sm text-navy-500">{level.description}</p>
                  </motion.button>
                ))}
              </div>
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-6">
            <div>
              <h3 className="font-display font-bold text-xl mb-2">Your availability</h3>
              <p className="text-navy-500 text-sm">Click to toggle when you're available</p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr>
                    <th className="text-left p-2"></th>
                    {weekDays.map(day => (
                      <th key={day} className="text-center p-2 text-xs font-semibold text-navy-600">{day}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {timeBlocks.map(time => (
                    <tr key={time}>
                      <td className="p-2 text-sm font-medium text-navy-600">{time}</td>
                      {weekDays.map(day => {
                        const isSelected = (profile.availability[day] || []).includes(time)
                        return (
                          <td key={`${day}-${time}`} className="p-1">
                            <button
                              onClick={() => toggleAvailability(day, time)}
                              className={`w-full aspect-square rounded-lg transition-all ${
                                isSelected 
                                  ? 'bg-electric text-white' 
                                  : 'bg-navy-100 hover:bg-navy-200'
                              }`}
                            >
                              {isSelected && <Check className="w-4 h-4 mx-auto" />}
                            </button>
                          </td>
                        )
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-4 bg-navy-50 rounded-xl">
              <p className="text-sm text-navy-600">
                <span className="font-semibold">Pro tip:</span> Cleaners who work weekends earn 30% more on average
              </p>
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-6">
            <div>
              <h3 className="font-display font-bold text-xl mb-2">Identity verification</h3>
              <p className="text-navy-500 text-sm">Upload a photo of your ID (passport or driving license)</p>
            </div>

            <div className="border-2 border-dashed border-navy-300 rounded-xl p-8 text-center hover:border-electric transition-colors cursor-pointer">
              <div className="w-16 h-16 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="w-8 h-8 text-navy-400" />
              </div>
              <p className="font-medium text-nearblack mb-1">Tap to upload photo</p>
              <p className="text-sm text-navy-500">JPG or PNG, max 5MB</p>
            </div>

            <div className="flex items-center gap-2 text-sm text-navy-600">
              <Shield className="w-4 h-4 text-emerald" />
              <span>Your data is encrypted and secure</span>
            </div>

            <button
              onClick={() => setVerificationComplete(true)}
              className="sc-btn-primary w-full"
            >
              {verificationComplete ? 'Uploaded!' : 'Upload ID'}
            </button>
          </div>
        )

      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-electric-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-electric" />
              </div>
              <h3 className="font-display font-bold text-2xl mb-2">Starter Kit</h3>
              <p className="text-navy-500">One-time fee to join the network</p>
            </div>

            <div className="sc-card p-6 border-2 border-electric">
              <div className="flex justify-between items-center mb-4">
                <span className="font-display font-bold text-3xl text-electric">£15</span>
                <span className="text-navy-500">one-time</span>
              </div>

              <ul className="space-y-3">
                {[
                  { icon: Shield, text: 'Background check (£10 value)' },
                  { icon: BadgeCheck, text: 'Insurance activation (£5 value)' },
                  { icon: MessageCircle, text: 'WhatsApp network access' },
                  { icon: Star, text: 'Welcome pack & training' },
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <item.icon className="w-5 h-5 text-emerald" />
                    <span className="text-navy-700">{item.text}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 bg-emerald-50 rounded-xl">
              <div className="flex items-start gap-3">
                <Check className="w-5 h-5 text-emerald flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-emerald-800">100% refund guarantee</p>
                  <p className="text-sm text-emerald-700 mt-1">If not approved within 48 hours</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-center gap-2 text-sm text-navy-500">
              <Lock className="w-4 h-4" />
              <span>Secure payment via Stripe</span>
            </div>

            <button className="sc-btn-primary w-full">
              Pay £15 & Join
            </button>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-navy-900/50 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="sc-card w-full max-w-lg max-h-[90vh] overflow-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-navy-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-electric rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold">Join SparkClean</span>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-navy-100 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="px-6 pt-6">
          <div className="sc-step-indicator">
            {[1, 2, 3, 4, 5].map((s) => (
              <div
                key={s}
                className={`sc-step-dot ${s === step ? 'active' : s < step ? 'completed' : ''}`}
              />
            ))}
          </div>
          <p className="text-sm text-navy-500 mt-2">Step {step} of 5</p>
        </div>

        {/* Content */}
        <div className="p-6">
          {renderStep()}
        </div>

        {/* Footer */}
        <div className="flex gap-3 p-6 border-t border-navy-100">
          {step > 1 && (
            <button
              onClick={() => setStep(step - 1)}
              className="sc-btn-secondary flex-1"
            >
              Back
            </button>
          )}
          <button
            onClick={() => step < 5 ? setStep(step + 1) : onClose()}
            className="sc-btn-primary flex-1"
          >
            {step === 5 ? 'Complete application' : 'Continue'}
          </button>
        </div>
      </motion.div>
    </motion.div>
  )
}

// Cleaner Dashboard Preview
function CleanerDashboard() {
  const [weeklyEarnings] = useState(485)
  const [weeklyTarget] = useState(600)
  const progress = (weeklyEarnings / weeklyTarget) * 100

  const upcomingJobs = [
    { id: 1, location: 'Chelsea', time: 'Tomorrow, 9AM', earnings: 45, duration: 3 },
    { id: 2, location: 'Fulham', time: 'Wed, 2PM', earnings: 60, duration: 4 },
    { id: 3, location: 'Kensington', time: 'Fri, 10AM', earnings: 75, duration: 5 },
  ]

  const heatmapData = [
    ['low', 'medium', 'high', 'high', 'very-high', 'medium', 'low'],
    ['low', 'low', 'medium', 'high', 'high', 'very-high', 'medium'],
    ['medium', 'low', 'low', 'medium', 'high', 'high', 'very-high'],
  ]

  return (
    <section className="py-20 md:py-32 bg-navy-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="sc-label text-electric mb-4 block">CLEANER DASHBOARD</span>
            <h2 className="font-display font-bold text-3xl md:text-4xl text-white mb-6">
              Track earnings, manage schedule, get paid instantly
            </h2>
            <p className="text-navy-300 text-lg mb-8">
              Our cleaner app puts you in control. See your weekly progress, accept jobs with a tap, 
              and transfer earnings to your bank instantly.
            </p>

            <div className="space-y-4">
              {[
                { icon: TrendingUp, text: 'Weekly target progress tracking' },
                { icon: MapPin, text: 'Demand heatmap by area' },
                { icon: Zap, text: 'Instant payout to your bank' },
                { icon: Calendar, text: 'Visual availability calendar' },
              ].map((feature, i) => (
                <div key={i} className="flex items-center gap-3 text-navy-200">
                  <feature.icon className="w-5 h-5 text-electric" />
                  <span>{feature.text}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right: Dashboard Preview */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="sc-card overflow-hidden"
          >
            {/* Dashboard Header */}
            <div className="p-6 border-b border-navy-100">
              <div className="flex items-center justify-between mb-4">
                <span className="text-navy-500">This week</span>
                <button className="text-electric font-semibold text-sm">Transfer to bank</button>
              </div>
              <div className="sc-income-display">£{weeklyEarnings}</div>
              <p className="text-navy-500 text-sm mt-1">of £{weeklyTarget} target</p>
              <div className="sc-target-progress mt-4">
                <div 
                  className="sc-target-fill" 
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            {/* Upcoming Jobs */}
            <div className="p-6 border-b border-navy-100">
              <h4 className="font-semibold mb-4">Upcoming jobs</h4>
              <div className="space-y-3">
                {upcomingJobs.map((job) => (
                  <div key={job.id} className="flex items-center justify-between p-3 bg-navy-50 rounded-xl">
                    <div>
                      <p className="font-medium text-nearblack">{job.location}</p>
                      <p className="text-sm text-navy-500">{job.time}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-display font-bold text-electric">£{job.earnings}</p>
                      <p className="text-xs text-navy-500">{job.duration} hrs</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Demand Heatmap */}
            <div className="p-6">
              <h4 className="font-semibold mb-4">Demand by area</h4>
              <div className="grid grid-cols-7 gap-1">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
                  <div key={day} className="text-center text-xs text-navy-500">{day}</div>
                ))}
                {heatmapData.flat().map((level, i) => (
                  <div 
                    key={i} 
                    className={`aspect-square rounded sc-heatmap-cell sc-heatmap-${level}`}
                  />
                ))}
              </div>
              <div className="flex items-center justify-between mt-3 text-xs text-navy-500">
                <span>Low demand</span>
                <span>High demand</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// Final CTA Section
function FinalCTASection({ onBookClick, onCleanerClick }: { onBookClick: () => void, onCleanerClick: () => void }) {
  return (
    <section className="py-20 md:py-32 bg-offwhite">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Book Cleaning CTA */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="sc-card p-8 md:p-12"
          >
            <h2 className="font-display font-bold text-3xl md:text-4xl mb-4">
              BOOK YOUR<br /><span className="text-electric">FIRST CLEAN.</span>
            </h2>
            <p className="text-navy-600 text-lg mb-8">
              Tell us what you need. We'll match you with a vetted cleaner in your area.
            </p>
            <button onClick={onBookClick} className="sc-btn-primary text-lg px-8 py-4">
              Get a quote
              <ArrowRight className="w-5 h-5 ml-2 inline" />
            </button>
            <p className="mt-4 text-sm text-navy-500">
              Free cancellation up to 24 hours before.
            </p>
          </motion.div>

          {/* Cleaner CTA */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="sc-card p-8 md:p-12 bg-navy-900 text-white"
          >
            <h2 className="font-display font-bold text-3xl md:text-4xl mb-4">
              WANT TO<br /><span className="text-electric">CLEAN WITH US?</span>
            </h2>
            <p className="text-navy-300 text-lg mb-8">
              Join as a vetted cleaner. Flexible hours, weekly pay, and support that respects your time.
            </p>
            <button onClick={onCleanerClick} className="sc-btn-primary text-lg px-8 py-4 bg-electric hover:bg-electric-600">
              Apply to clean
              <ArrowRight className="w-5 h-5 ml-2 inline" />
            </button>
            <p className="mt-4 text-sm text-navy-400">
              £15 starter kit • Approved in 48hrs
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// Footer
function Footer() {
  return (
    <footer className="bg-navy-900 text-navy-300 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-electric rounded-lg flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="font-display font-bold text-xl text-white">SparkClean</span>
            </div>
            <p className="text-sm">Spotless homes. Zero stress.</p>
          </div>
          
          <div>
            <h4 className="font-semibold text-white mb-4">Customers</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Book a clean</a></li>
              <li><a href="#" className="hover:text-white transition-colors">How it works</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Support</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-white mb-4">Cleaners</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Apply to clean</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Cleaner app</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Earnings</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Safety</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-white mb-4">Contact</h4>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                <a href="tel:02079460958" className="hover:text-white transition-colors">020 7946 0958</a>
              </li>
              <li className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-navy-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm">© 2025 SparkClean. All rights reserved.</p>
          <div className="flex gap-4 text-sm">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  )
}

// Main App
function App() {
  const [showBookingFlow, setShowBookingFlow] = useState(false)
  const [showCleanerFlow, setShowCleanerFlow] = useState(false)

  const scrollToBooking = () => {
    setShowBookingFlow(true)
  }

  const scrollToCleaner = () => {
    setShowCleanerFlow(true)
  }

  return (
    <div className="relative">
      {/* Grain Overlay */}
      <div className="sc-grain" />

      {/* Navigation */}
      <Navigation onBookClick={scrollToBooking} onCleanerClick={scrollToCleaner} />

      {/* Main Content */}
      <main>
        <HeroSection onBookClick={scrollToBooking} />
        <ValuePropSection />
        <TrustSection />
        <FeatureSection
          headline="YOU'RE IN"
          highlight="CONTROL."
          cardTitle="Flexible scheduling"
          bullets={[
            "Book, reschedule, or skip with a tap.",
            "Choose weekly, fortnightly, or one-off.",
            "Same cleaner every time (if you want)."
          ]}
          linkText="See how it works"
          imageUrl="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1920&q=80"
        />
        <FeatureSection
          headline="SPOTLESS"
          highlight="HOMES."
          cardTitle="Quality you can see"
          bullets={[
            "Vetted, trained cleaners.",
            "Eco-friendly products available.",
            "Satisfaction follow-up after every clean."
          ]}
          linkText="What's included"
          imageUrl="https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=1920&q=80"
        />
        <FeatureSection
          headline="ZERO"
          highlight="STRESS."
          cardTitle="Fair, transparent pricing"
          bullets={[
            "Pay securely after each clean.",
            "No lock-in contracts.",
            "Support team replies in minutes."
          ]}
          linkText="Support center"
          imageUrl="https://images.unsplash.com/photo-1600573472592-401b489a3cdc?w=1920&q=80"
        />
        <CleanerDashboard />
        <FinalCTASection onBookClick={scrollToBooking} onCleanerClick={scrollToCleaner} />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating Pill CTA */}
      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        onClick={scrollToBooking}
        className="sc-pill-cta"
      >
        Book a clean
      </motion.button>

      {/* Modals */}
      <AnimatePresence>
        {showBookingFlow && <BookingFlow onClose={() => setShowBookingFlow(false)} />}
        {showCleanerFlow && <CleanerApplicationFlow onClose={() => setShowCleanerFlow(false)} />}
      </AnimatePresence>
    </div>
  )
}

export default App
